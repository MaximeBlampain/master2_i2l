##TodoLists
###Author: Maxime Blampain

- Dashboard (stats):
    * Todolist (les taches avec les deadlines les plus récentes)
    * Stats (nombre de tâches complétées...)
- Liste des tâches :
    * Recherche de tâches
    * Ajout de tâches
    * Suppression de tâches
    * Compléter une tâche
- Modification / Création d'une tâche
- Persistance des données
- Utiliser une librairie CSS externe avec des composants react

Liste :
- Liste de tâches (titre, description, deadline, statut)

##How to launch project ? 

Please run `npm install` before to get all nodes_modules.

Then, run `npm start` to launch the project.
