package drawing;

import javafx.scene.shape.Rectangle;
import javafx.scene.shape.Polygon;
import javafx.scene.shape.Shape;

public class TriangleButtonHandler extends ShapeButtonHandler {

    public TriangleButtonHandler(DrawingPane drawingPane) {
        super(drawingPane);
    }

    @Override
    protected IShape createShape() {
        double x = Math.min(originX, destinationX);
        double y = Math.min(originY, destinationY);
        double width = Math.abs(destinationX - originX);
        double height = Math.abs(destinationY - originY);
        double endX = Math.max(originX, destinationX);
        double endY = Math.max(originY, destinationY);
        Polygon triangle = new Polygon();
        triangle.getPoints().addAll(x, y,
                endX + 10.0, endY + 10.0,
                endX - 10.0, endY  + 10.0);
        triangle.getStyleClass().add("triangle");
        IShape newTriangle = new ShapeAdapter(triangle);
        return newTriangle;
    }
}
