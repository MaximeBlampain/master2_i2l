package drawing;

import javafx.event.EventHandler;
import javafx.scene.input.KeyEvent;

public class SelectionHandler implements EventHandler<KeyEvent> {

    private DrawingPane drawingPane;

    public SelectionHandler(DrawingPane drawingPane) {
        this.drawingPane = drawingPane;
        drawingPane.addEventHandler(KeyEvent.KEY_PRESSED, this);
        drawingPane.addEventHandler(KeyEvent.KEY_RELEASED, this);
    }

    @Override
    public void handle(KeyEvent keyEvent) {

    }
}
