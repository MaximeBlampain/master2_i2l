package drawing;

import javafx.geometry.Insets;
import javafx.scene.control.Label;
import javafx.scene.layout.HBox;

import java.awt.*;
import java.util.ArrayList;

public class StatutBar extends HBox implements Observer {

    private final Label label;

    public StatutBar() {
        label = new Label("0 shape");
        this.getChildren().addAll(label);
        this.setPadding(new Insets(5));
        this.setSpacing(5.0);
        this.getStyleClass().add("bottomIndicator");
    }

    @Override
    public void update(int size) {
        if(size > 1)
            label.setText(size + " shapes");
        else
            label.setText(size + " shape");
    }
}
