# TP1 - POOA

### Maxime BLAMPAIN

---

- **Question 1** :
    La méthode toString permet de convertir l'objet en question 
    en une suite de chaine de caractère pour voir le nom de la 
    classe si cette méthode n'est pas surchargée.
  

- **Question 2** :
    On apprend que le vecteur possède une interface et 3 autres éléments avec des types différents.
  

- **Question 3** :
    On remarque qu'il y a une classe qui surchage sa méthode toString
  

- **Question 4** :
    Non, les classes définissent des objets. Pour autant, un objet de la classe Class peut etre instancié.

- **Question 5** : 
    On peut accéder à tous les attributs de la classe, ses constructeurs et ses méthodes

  
- **Question 7** :
  

- **Question 8** :


- **Question 9** :
    La classe Class est finale car elle ne doit pas être overwrite


- **Question 10** :
    

- **Question 11** :
    Il permet de définir si le champ est accessible ou non via un systeme de sécurité

  
- **Question 12** : *TO-DO*


- **Question 13** : *TO-DO*
    

